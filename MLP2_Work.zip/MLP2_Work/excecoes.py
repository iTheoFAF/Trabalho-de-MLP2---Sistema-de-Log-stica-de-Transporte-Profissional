# Exceções Personalizadas

class PesoInvalidoException(Exception):
    pass


class CapacidadeExcedidaException(Exception):
    pass


class ClienteNaoEncontradoException(Exception):
    pass