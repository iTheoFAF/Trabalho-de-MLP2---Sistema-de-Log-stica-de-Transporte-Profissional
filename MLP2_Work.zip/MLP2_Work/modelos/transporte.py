from .seguro import Seguro


class Transporte:
    def __init__(self, capacidade: float):
        self.capacidade = capacidade

    def calcular_custo(self):
        return 0

    def tipo_transporte(self):
        return "Transporte genérico"

    def emitir_relatorio(self):
        return "Relatório padrão"


class Van(Transporte, Seguro):
    def __init__(self, capacidade: float):
        super().__init__(capacidade)
        self.portas = 4
        self.consumo = 10

    def calcular_custo(self):
        return 50

    def tipo_transporte(self):
        return "Van (transporte leve)"

    def emitir_relatorio(self):
        return "Utilizada para pequenas cargas"


class Caminhao(Transporte, Seguro):
    def __init__(self, capacidade: float):
        super().__init__(capacidade)
        self.eixos = 6
        self.consumo = 5

    def calcular_custo(self):
        return 150

    def tipo_transporte(self):
        return "Caminhão (transporte pesado)"

    def emitir_relatorio(self):
        return "Utilizado para grandes cargas"


class Onibus(Transporte, Seguro):
    def __init__(self, capacidade: float):
        super().__init__(capacidade)
        self.assentos = 40
        self.ar_condicionado = True

    def calcular_custo(self):
        return 100

    def tipo_transporte(self):
        return "Ônibus (transporte coletivo)"

    def emitir_relatorio(self):
        return "Utilizado para transporte de passageiros"