from .pessoa import Pessoa
from .cliente import Cliente, ClientePremium
from .seguro import Seguro
from .transporte import Transporte, Van, Caminhao, Onibus

#O "All" facilitará a exibição das informações requerentes no banco posteriormente.

__all__ = [
    'Pessoa',
    'Cliente',
    'ClientePremium',
    'Seguro',
    'Transporte',
    'Van',
    'Caminhao',
    'Onibus',
]