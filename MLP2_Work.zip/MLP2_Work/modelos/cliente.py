from .pessoa import Pessoa


class Cliente(Pessoa):
    def __init__(self, nome: str, cpf: str):
        super().__init__(nome, cpf)


class ClientePremium(Cliente):
    def __init__(self, nome: str, cpf: str, desconto: float):
        super().__init__(nome, cpf)
        self.desconto = desconto