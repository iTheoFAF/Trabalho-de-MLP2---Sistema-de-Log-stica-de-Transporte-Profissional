class Seguro:
    def validar_seguro(self):
        return "Seguro válido"