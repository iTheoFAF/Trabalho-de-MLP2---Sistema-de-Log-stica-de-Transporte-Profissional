import sqlite3
from banco_dados import DB_PATH
from banco_dados import conectar

conn = conectar()
cursor = conn.cursor()

cursor.execute("""
    UPDATE clientes
    set id = 1
    WHERE nome = Théo Athayde;
""")

conn.commit()
conn.close()

print("Comando executado.")