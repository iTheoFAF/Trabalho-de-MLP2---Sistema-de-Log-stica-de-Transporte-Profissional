from modelos import Cliente, ClientePremium
from excecoes import ClienteNaoEncontradoException
from banco_dados import (
    salvar_cliente,
    carregar_todos_clientes,
    verificar_cliente_existe,
    deletar_cliente,
)


def cadastrar_cliente():
    try:
        nome = input("Nome: ")
        cpf = input("CPF: ")

        # Validação de dados vazios
        if not nome or not cpf:
            raise ClienteNaoEncontradoException("Dados inválidos!")

        # Validação de CPF duplicado
        if verificar_cliente_existe(cpf):
            print("❌ Cliente já cadastrado!")
            return

        tipo = input("Cliente Premium? (s/n): ").lower()

        if tipo == "s":
            desconto = float(input("Desconto (%): "))
            cliente = ClientePremium(nome, cpf, desconto)
        else:
            cliente = Cliente(nome, cpf)

        salvar_cliente(cliente)

    except ValueError:
        print("❌ Erro: valor inválido!")

    except ClienteNaoEncontradoException as e:
        print("❌ Erro:", e)

    else:
        print("✓ Cliente cadastrado com sucesso!")

    finally:
        print("Operação finalizada.\n")


def listar_clientes():
    clientes = carregar_todos_clientes()

    if not clientes:
        print("Nenhum cliente cadastrado.")
        return

    print("\n--- CLIENTES CADASTRADOS ---")
    for c in clientes.values():
        if isinstance(c, ClientePremium):
            print(f"⭐ {c.nome} - CPF: {c.cpf} (Desconto: {c.desconto}%)")
        else:
            print(f"   {c.nome} - CPF: {c.cpf}")
    print()


def listar_clientes_premium():
    clientes = carregar_todos_clientes()

    # Lista de Compreensão
    premium = [c for c in clientes.values() if isinstance(c, ClientePremium)]

    if not premium:
        print("Nenhum cliente premium cadastrado.")
        return

    print("\n--- CLIENTES PREMIUM ---")
    for c in premium:
        print(f"⭐ {c.nome} (Desconto: {c.desconto}%)")
    print()