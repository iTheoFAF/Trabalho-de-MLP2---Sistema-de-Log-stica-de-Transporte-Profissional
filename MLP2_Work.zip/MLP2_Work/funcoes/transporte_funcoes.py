from modelos import Van, Caminhao, Onibus
from excecoes import PesoInvalidoException, CapacidadeExcedidaException
from banco_dados import (
    salvar_transporte,
    carregar_todos_transportes,
    listar_transportes_info,
    deletar_transporte,
)


def cadastrar_transporte():
    try:
        capacidade = float(input("Capacidade(kg): "))

        # Validação de capacidade
        if capacidade <= 0:
            raise PesoInvalidoException("Capacidade inválida!")

        if capacidade > 10000:
            raise CapacidadeExcedidaException("Capacidade excedida!")

        print("1 - Van | 2 - Caminhão | 3 - Ônibus")
        tipo = input("Escolha o tipo: ")

        match tipo:
            case "1":
                t = Van(capacidade)
            case "2":
                t = Caminhao(capacidade)
            case "3":
                t = Onibus(capacidade)
            case _:
                print("❌ Tipo inválido!")
                return

        salvar_transporte(t)

    except ValueError:
        print("❌ Digite um número válido!")

    except (PesoInvalidoException, CapacidadeExcedidaException) as e:
        print("❌ Erro:", e)

    else:
        print("✓ Transporte cadastrado!")

    finally:
        print("Fim da operação.\n")


def listar_transportes():
    transportes = carregar_todos_transportes()

    if not transportes:
        print("Nenhum transporte cadastrado.")
        return

    print("\n--- TRANSPORTES CADASTRADOS ---")
    for t in transportes:
        print(f"🚚 {t.tipo_transporte()} | Capacidade: {t.capacidade}kg | Custo: R$ {t.calcular_custo()}")
        # Uso do polimorfismo no relatório
        print(f"   Relatório: {t.emitir_relatorio()}")
        # Uso da herança múltipla (seguro)
        print(f"   {t.validar_seguro()}\n")