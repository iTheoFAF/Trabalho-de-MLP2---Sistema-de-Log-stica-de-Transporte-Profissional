import sqlite3
from modelos import Cliente, ClientePremium, Van, Caminhao, Onibus

# Caminho do banco de dados
DB_PATH = "gestao_transportes.db"

def conectar():
    """Conecta ao banco de dados"""
    return sqlite3.connect(DB_PATH)


def criar_tabelas():
    """Cria as tabelas do banco se não existirem"""
    conn = conectar()
    cursor = conn.cursor()

    # Tabela de Clientes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clientes (
            cpf TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            desconto REAL DEFAULT 0,
            premium INTEGER DEFAULT 0
        )
    """)

    # Tabela de Transportes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transportes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL,
            capacidade REAL NOT NULL,
            portas INTEGER,
            eixos INTEGER,
            assentos INTEGER
        )
    """)

    conn.commit()
    conn.close()
    print("✓ Banco de dados inicializado!")


# ==================== CLIENTES ====================

def salvar_cliente(cliente):
    """Salva um cliente no banco"""
    conn = conectar()
    cursor = conn.cursor()

    premium = 1 if isinstance(cliente, ClientePremium) else 0
    desconto = cliente.desconto if isinstance(cliente, ClientePremium) else 0

    try:
        cursor.execute("""
            INSERT INTO clientes (cpf, nome, premium, desconto)
            VALUES (?, ?, ?, ?)
        """, (cliente.cpf, cliente.nome, premium, desconto))
        conn.commit()
    except sqlite3.IntegrityError:
        print("Cliente já existe!")
    finally:
        conn.close()


def carregar_cliente(cpf):
    """Carrega um cliente do banco pelo CPF"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("SELECT cpf, nome, premium, desconto FROM clientes WHERE cpf = ?", (cpf,))
    resultado = cursor.fetchone()
    conn.close()

    if resultado:
        cpf, nome, premium, desconto = resultado
        if premium:
            return ClientePremium(nome, cpf, desconto)
        else:
            return Cliente(nome, cpf)
    return None


def carregar_todos_clientes():
    """Carrega todos os clientes do banco"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("SELECT cpf, nome, premium, desconto FROM clientes")
    resultados = cursor.fetchall()
    conn.close()

    clientes = {}
    for cpf, nome, premium, desconto in resultados:
        if premium:
            cliente = ClientePremium(nome, cpf, desconto)
        else:
            cliente = Cliente(nome, cpf)
        clientes[cpf] = cliente

    return clientes


def verificar_cliente_existe(cpf):
    """Verifica se um cliente já existe"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM clientes WHERE cpf = ?", (cpf,))
    existe = cursor.fetchone()[0] > 0
    conn.close()

    return existe


def deletar_cliente(cpf):
    """Deleta um cliente do banco"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM clientes WHERE cpf = ?", (cpf,))
    conn.commit()
    conn.close()


# ==================== TRANSPORTES ====================

def salvar_transporte(transporte):
    """Salva um transporte no banco"""
    conn = conectar()
    cursor = conn.cursor()

    tipo = transporte.tipo_transporte()

    if isinstance(transporte, Van):
        cursor.execute("""
            INSERT INTO transportes (tipo, capacidade, portas)
            VALUES (?, ?, ?)
        """, (tipo, transporte.capacidade, transporte.portas))

    elif isinstance(transporte, Caminhao):
        cursor.execute("""
            INSERT INTO transportes (tipo, capacidade, eixos)
            VALUES (?, ?, ?)
        """, (tipo, transporte.capacidade, transporte.eixos))

    elif isinstance(transporte, Onibus):
        cursor.execute("""
            INSERT INTO transportes (tipo, capacidade, assentos)
            VALUES (?, ?, ?)
        """, (tipo, transporte.capacidade, transporte.assentos))

    conn.commit()
    conn.close()


def carregar_transporte(transporte_id):
    """Carrega um transporte do banco pelo ID"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, tipo, capacidade, portas, eixos, assentos
        FROM transportes WHERE id = ?
    """, (transporte_id,))
    resultado = cursor.fetchone()
    conn.close()

    if resultado:
        id, tipo, capacidade, portas, eixos, assentos = resultado

        if "Van" in tipo:
            return Van(capacidade)
        elif "Caminhão" in tipo:
            return Caminhao(capacidade)
        elif "Ônibus" in tipo:
            return Onibus(capacidade)

    return None


def carregar_todos_transportes():
    """Carrega todos os transportes do banco"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, tipo, capacidade, portas, eixos, assentos
        FROM transportes
    """)
    resultados = cursor.fetchall()
    conn.close()

    transportes = []
    for id, tipo, capacidade, portas, eixos, assentos in resultados:
        if "Van" in tipo:
            transporte = Van(capacidade)
        elif "Caminhão" in tipo:
            transporte = Caminhao(capacidade)
        elif "Ônibus" in tipo:
            transporte = Onibus(capacidade)
        else:
            continue

        transportes.append(transporte)

    return transportes


def deletar_transporte(transporte_id):
    """Deleta um transporte do banco"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM transportes WHERE id = ?", (transporte_id,))
    conn.commit()
    conn.close()


def listar_transportes_info():
    """Lista transportes com suas informações (para exibição)"""
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, tipo, capacidade FROM transportes
    """)
    resultados = cursor.fetchall()
    conn.close()

    return resultados