from funcoes import (
    cadastrar_cliente,
    listar_clientes,
    listar_clientes_premium,
    cadastrar_transporte,
    listar_transportes,
)
from banco_dados import criar_tabelas


def menu():
    while True:
        print("\n" + "="*40)
        print("   GERENCIADOR DE TRANSPORTES")
        print("="*40)
        print("1 - Cadastrar cliente")
        print("2 - Listar clientes")
        print("3 - Listar clientes premium")
        print("4 - Cadastrar transporte")
        print("5 - Listar transportes")
        print("0 - Sair")
        print("="*40)

        opcao = input("Escolha uma opção: ")

        match opcao:
            case "1":
                cadastrar_cliente()
            case "2":
                listar_clientes()
            case "3":
                listar_clientes_premium()
            case "4":
                cadastrar_transporte()
            case "5":
                listar_transportes()
            case "0":
                print("\n👋 Saindo... Até logo!")
                break
            case _:
                print("❌ Opção inválida!")


if __name__ == "__main__":
    #Inicializa o banco de dados
    criar_tabelas()
    menu()